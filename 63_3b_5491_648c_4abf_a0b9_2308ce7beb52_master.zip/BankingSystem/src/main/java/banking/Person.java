package banking;

public class Person {
	private String firstName;
	private String lastName;

	public Person(String firstName, String lastName, int idNumber) {
		// complete the function
	}

	public String getFirstName() {
		// complete the function
        return null;
	}

	public String getLastName() {
		// complete the function
        return null;
	}
}
